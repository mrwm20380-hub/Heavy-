# رواسي الشاهقة v3
نسخة تطبيق فعلية بدون صور تسويقية.

النسخة الحالية:
- واجهة سائق ومشرف.
- تصوير العطل إجباري.
- إضافة موقع العطل عبر Google Maps.
- التقاط الموقع الحالي من GPS أو اختيار نقطة على الخريطة.
- حزم Firebase موجودة ومجهزة للمرحلة التالية.

المرحلة التالية بعد بناء الواجهة:
1. ربط Firebase Authentication.
2. حفظ بلاغ السائق في Firestore.
3. رفع صور البلاغ إلى Firebase Storage.
4. عرض البلاغ فوراً عند المشرف.
5. إرسال إشعار Firebase Cloud Messaging للمشرف عند البلاغ الجديد.

مطلوب لتفعيل الخريطة: وضع Google Maps Android API Key مكان
PUT_GOOGLE_MAPS_API_KEY_HERE في AndroidManifest.xml.
