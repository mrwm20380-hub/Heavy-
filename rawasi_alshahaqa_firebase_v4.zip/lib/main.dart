import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';

const navy=Color(0xFF0B1736), navy2=Color(0xFF14264D), red=Color(0xFFE53935), bg=Color(0xFFF4F6FA), text=Color(0xFF172033), muted=Color(0xFF748096);

void main()=>runApp(const RawasiApp());

class RawasiApp extends StatelessWidget{
 const RawasiApp({super.key});
 @override Widget build(BuildContext c)=>MaterialApp(
  debugShowCheckedModeBanner:false,title:'رواسي الشاهقة',
  theme:ThemeData(useMaterial3:true,scaffoldBackgroundColor:bg,colorScheme:ColorScheme.fromSeed(seedColor:red),cardTheme:CardThemeData(elevation:0,margin:EdgeInsets.zero,color:Colors.white,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(20))),inputDecorationTheme:InputDecorationTheme(filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:BorderSide.none))),
  home:const Directionality(textDirection:TextDirection.rtl,child:Home()));
}

class Home extends StatelessWidget{
 const Home({super.key});
 @override Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:ListView(padding:const EdgeInsets.all(22),children:[
  const SizedBox(height:28),
  Container(width:86,height:86,decoration:BoxDecoration(color:navy,borderRadius:BorderRadius.circular(26)),child:const Icon(Icons.local_shipping_rounded,color:Colors.white,size:44)),
  const SizedBox(height:22),const Text('رواسي الشاهقة',style:TextStyle(fontSize:31,fontWeight:FontWeight.w900,color:navy)),
  const SizedBox(height:7),const Text('إدارة أسطول النقل والصيانة',style:TextStyle(fontSize:16,color:muted)),
  const SizedBox(height:42),
  RoleCard(icon:Icons.drive_eta_rounded,title:'تطبيق السائق',subtitle:'بلاغ الأعطال وتصويرها ومتابعتها',color:red,onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const DriverHome()))),
  const SizedBox(height:16),
  RoleCard(icon:Icons.dashboard_rounded,title:'لوحة المشرف',subtitle:'المركبات والأعطال وسجل الصيانة',color:navy,onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const SupervisorHome()))),
  const SizedBox(height:35),const Center(child:Text('نسخة تجريبية • قبل الربط السحابي',style:TextStyle(color:muted,fontSize:12)))
 ])));
}
class RoleCard extends StatelessWidget{
 final IconData icon;final String title,subtitle;final Color color;final VoidCallback onTap;
 const RoleCard({super.key,required this.icon,required this.title,required this.subtitle,required this.color,required this.onTap});
 @override Widget build(BuildContext c)=>InkWell(borderRadius:BorderRadius.circular(24),onTap:onTap,child:Ink(padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(24),boxShadow:[BoxShadow(color:Colors.black.withOpacity(.05),blurRadius:18,offset:const Offset(0,8))]),child:Row(children:[
  Container(width:58,height:58,decoration:BoxDecoration(color:color.withOpacity(.1),borderRadius:BorderRadius.circular(18)),child:Icon(icon,color:color,size:30)),
  const SizedBox(width:16),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w800,color:text)),const SizedBox(height:5),Text(subtitle,style:const TextStyle(color:muted,height:1.35))])),
  const Icon(Icons.arrow_forward_ios_rounded,size:16,color:muted)
 ])));
}

class DriverHome extends StatefulWidget{const DriverHome({super.key});@override State<DriverHome> createState()=>_DriverHomeState();}
class _DriverHomeState extends State<DriverHome>{
 final faults=<Map<String,dynamic>>[];
 @override Widget build(BuildContext c)=>Scaffold(
  appBar:AppBar(title:const Text('مرحباً أيها السائق',style:TextStyle(fontWeight:FontWeight.w800)),actions:[IconButton(onPressed:(){},icon:const Icon(Icons.notifications_none_rounded))]),
  body:ListView(padding:const EdgeInsets.fromLTRB(18,4,18,110),children:[
   const VehicleBanner(),const SizedBox(height:22),
   Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('بلاغاتي',style:TextStyle(fontSize:21,fontWeight:FontWeight.w900,color:text)),Text('${faults.length} بلاغ',style:const TextStyle(color:muted))]),
   const SizedBox(height:12),
   if(faults.isEmpty)const EmptyState() else ...faults.map((f)=>FaultCard(f))
  ]),
  floatingActionButton:FloatingActionButton.extended(backgroundColor:red,foregroundColor:Colors.white,onPressed:()async{final r=await Navigator.push<Map<String,dynamic>>(c,MaterialPageRoute(builder:(_)=>const AddFaultPage()));if(r!=null)setState(()=>faults.insert(0,r));},icon:const Icon(Icons.camera_alt_rounded),label:const Text('تصوير عطل',style:TextStyle(fontWeight:FontWeight.bold)))
 );
}
class VehicleBanner extends StatelessWidget{const VehicleBanner({super.key});@override Widget build(BuildContext c)=>Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(gradient:const LinearGradient(colors:[navy,navy2]),borderRadius:BorderRadius.circular(24)),child:const Row(children:[
 Container(width:60,height:60,decoration:BoxDecoration(color:Color(0x221FFFFFF),borderRadius:BorderRadius.all(Radius.circular(18))),child:Icon(Icons.local_shipping_rounded,color:Colors.white,size:32)),
 SizedBox(width:16),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('المركبة المخصصة لك',style:TextStyle(color:Colors.white70)),SizedBox(height:4),Text('شاحنة 01 • 1234 أ ب',style:TextStyle(color:Colors.white,fontSize:18,fontWeight:FontWeight.w800)),SizedBox(height:5),Text('الحالة: جاهزة للعمل',style:TextStyle(color:Colors.white70))])),Icon(Icons.verified_rounded,color:Colors.white,size:28)
]));}
class EmptyState extends StatelessWidget{const EmptyState({super.key});@override Widget build(BuildContext c)=>Container(padding:const EdgeInsets.symmetric(vertical:50,horizontal:25),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(22)),child:const Column(children:[Icon(Icons.check_circle_outline_rounded,size:60,color:Color(0xFF27AE60)),SizedBox(height:14),Text('لا توجد بلاغات',style:TextStyle(fontSize:18,fontWeight:FontWeight.w800,color:text)),SizedBox(height:6),Text('إذا لاحظت عطلاً، صوّره وأرسل البلاغ فوراً.',textAlign:TextAlign.center,style:TextStyle(color:muted))]));}
class FaultCard extends StatelessWidget{final Map<String,dynamic> f;const FaultCard(this.f,{super.key});@override Widget build(BuildContext c)=>Container(margin:const EdgeInsets.only(bottom:10),padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(18)),child:Row(children:[
 Container(width:48,height:48,decoration:BoxDecoration(color:red.withOpacity(.1),borderRadius:BorderRadius.circular(14)),child:const Icon(Icons.warning_amber_rounded,color:red)),const SizedBox(width:13),
 Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(f['type'],style:const TextStyle(fontWeight:FontWeight.w800,color:text)),const SizedBox(height:4),Text(f['description'],maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(color:muted))])),
 Pill(f['severity'])
]));}
class Pill extends StatelessWidget{final String value;const Pill(this.value,{super.key});@override Widget build(BuildContext c)=>Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:6),decoration:BoxDecoration(color:value=='إيقاف فوري'?red.withOpacity(.1):navy.withOpacity(.07),borderRadius:BorderRadius.circular(20)),child:Text(value,style:TextStyle(fontSize:11,fontWeight:FontWeight.w800,color:value=='إيقاف فوري'?red:navy)));}
class AddFaultPage extends StatefulWidget{const AddFaultPage({super.key});@override State<AddFaultPage> createState()=>_AddFaultPageState();}
class _AddFaultPageState extends State<AddFaultPage>{
 final desc=TextEditingController();final picker=ImagePicker();final pics=<XFile>[];String type='فرامل',severity='عادي';
 Future<void> takePhoto()async{final p=await picker.pickImage(source:ImageSource.camera,imageQuality:82);if(p!=null)setState(()=>pics.add(p));}
 void submit(){if(pics.isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تصوير العطل إجباري قبل الإرسال')));return;}if(desc.text.trim().isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('اكتب وصف العطل')));return;}Navigator.pop(context,{'type':type,'severity':severity,'description':desc.text.trim(),'photos':pics.length,'location':location});}
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('بلاغ عطل جديد',style:TextStyle(fontWeight:FontWeight.w800))),body:ListView(padding:const EdgeInsets.all(18),children:[
  Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:navy,borderRadius:BorderRadius.circular(22)),child:const Row(children:[Icon(Icons.camera_alt_rounded,color:Colors.white,size:30),SizedBox(width:12),Expanded(child:Text('صوّر العطل أولاً\\nالصورة مطلوبة لإرسال البلاغ',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w700,height:1.4)))])),
  const SizedBox(height:18),const Text('نوع العطل',style:TextStyle(fontWeight:FontWeight.w800,color:text)),const SizedBox(height:7),
  DropdownButtonFormField<String>(value:type,items:['فرامل','إطارات','محرك','كهرباء','تعليق','تسريب','إضاءة','أخرى'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>type=v!)),
  const SizedBox(height:14),const Text('درجة الخطورة',style:TextStyle(fontWeight:FontWeight.w800,color:text)),const SizedBox(height:7),
  DropdownButtonFormField<String>(value:severity,items:['عادي','متوسط','خطير','إيقاف فوري'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>severity=v!)),
  const SizedBox(height:14),const Text('وصف العطل',style:TextStyle(fontWeight:FontWeight.w800,color:text)),const SizedBox(height:7),
  TextField(controller:desc,maxLines:4,decoration:const InputDecoration(hintText:'اكتب ما لاحظته بالتفصيل...')),
  const SizedBox(height:16),FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:red,padding:const EdgeInsets.symmetric(vertical:16),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16))),onPressed:takePhoto,icon:const Icon(Icons.camera_alt_rounded),label:Text(pics.isEmpty?'فتح الكاميرا وتصوير العطل':'إضافة صورة أخرى (${pics.length})')),
  if(pics.isNotEmpty) ...[const SizedBox(height:12),SizedBox(height:105,child:ListView.separated(scrollDirection:Axis.horizontal,itemCount:pics.length,separatorBuilder:(_,__)=>const SizedBox(width:8),itemBuilder:(_,i)=>ClipRRect(borderRadius:BorderRadius.circular(14),child:Image.file(File(pics[i].path),width:105,height:105,fit:BoxFit.cover))))],
  const SizedBox(height:20),FilledButton(style:FilledButton.styleFrom(backgroundColor:navy,padding:const EdgeInsets.symmetric(vertical:16),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16))),onPressed:submit,child:const Text('إرسال البلاغ',style:TextStyle(fontWeight:FontWeight.w800)))
 ]));
}

class SupervisorHome extends StatefulWidget{const SupervisorHome({super.key});@override State<SupervisorHome> createState()=>_SupervisorHomeState();}
class _SupervisorHomeState extends State<SupervisorHome>{
 int tab=0;final vehicles=[('1234 أ ب','شاحنة 01','تعمل'),('5678 ج د','شاحنة 02','تعمل'),('9012 هـ و','شاحنة 03','صيانة')];
 @override Widget build(BuildContext c){final pages=[dashboard(),vehiclePage(),const Center(child:Text('سجل الصيانة — سيتم تطويره في المرحلة التالية',style:TextStyle(color:muted,fontSize:16)))];return Scaffold(appBar:AppBar(title:Text(['لوحة التحكم','المركبات','الصيانة'][tab],style:const TextStyle(fontWeight:FontWeight.w900))),body:pages[tab],bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:const[NavigationDestination(icon:Icon(Icons.dashboard_outlined),selectedIcon:Icon(Icons.dashboard),label:'الرئيسية'),NavigationDestination(icon:Icon(Icons.local_shipping_outlined),selectedIcon:Icon(Icons.local_shipping),label:'المركبات'),NavigationDestination(icon:Icon(Icons.build_outlined),selectedIcon:Icon(Icons.build),label:'الصيانة')]));}
 Widget dashboard()=>ListView(padding:const EdgeInsets.all(18),children:[const Text('ملخص الأسطول',style:TextStyle(fontSize:23,fontWeight:FontWeight.w900,color:text)),const SizedBox(height:15),Row(children:[Expanded(child:metric('المركبات','3',Icons.local_shipping,navy)),const SizedBox(width:10),Expanded(child:metric('أعطال مفتوحة','0',Icons.warning_amber,red))]),const SizedBox(height:10),metric('أعطال عاجلة','0',Icons.priority_high,red),const SizedBox(height:22),const Text('حالة النظام',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900,color:text)),const SizedBox(height:10),Container(padding:const EdgeInsets.all(17),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(18)),child:const Row(children:[Icon(Icons.cloud_done_rounded,color:Color(0xFF27AE60)),SizedBox(width:12),Expanded(child:Text('الوضع التجريبي — سيتم تفعيل المزامنة بين الأجهزة عند ربط Firebase',style:TextStyle(color:muted,height:1.4)))]))]);
 Widget metric(String a,String b,IconData i,Color c)=>Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(19)),child:Row(children:[Container(width:46,height:46,decoration:BoxDecoration(color:c.withOpacity(.1),borderRadius:BorderRadius.circular(14)),child:Icon(i,color:c)),const SizedBox(width:11),Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(color:muted,fontSize:12)),Text(b,style:const TextStyle(fontSize:25,fontWeight:FontWeight.w900,color:text))])]));
 Widget vehiclePage()=>ListView(padding:const EdgeInsets.all(18),children:vehicles.map((v)=>Container(margin:const EdgeInsets.only(bottom:10),padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(19)),child:ListTile(contentPadding:EdgeInsets.zero,leading:Container(width:52,height:52,decoration:BoxDecoration(color:navy.withOpacity(.08),borderRadius:BorderRadius.circular(15)),child:const Icon(Icons.local_shipping,color:navy)),title:Text(v.$2,style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text('لوحة ${v.$1}',style:const TextStyle(color:muted)),trailing:Pill(v.$3),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>VehicleDetails(name:v.$2,plate:v.$1))))).toList());
}
class VehicleDetails extends StatelessWidget{final String name,plate;const VehicleDetails({super.key,required this.name,required this.plate});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Text(name,style:const TextStyle(fontWeight:FontWeight.w800))),body:ListView(padding:const EdgeInsets.all(18),children:[
 Container(padding:const EdgeInsets.all(22),decoration:BoxDecoration(gradient:const LinearGradient(colors:[navy,navy2]),borderRadius:BorderRadius.circular(24)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Icon(Icons.local_shipping_rounded,color:Colors.white,size:45),const SizedBox(height:15),Text(name,style:const TextStyle(color:Colors.white,fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:5),Text('رقم اللوحة: $plate',style:const TextStyle(color:Colors.white70))])),
 const SizedBox(height:18),section(Icons.warning_amber_rounded,'الأعطال السابقة','لا توجد بيانات تجريبية حتى الآن'),const SizedBox(height:10),section(Icons.build_rounded,'سجل الصيانة','لا توجد بيانات تجريبية حتى الآن'),const SizedBox(height:10),section(Icons.photo_library_rounded,'الصور','ستظهر هنا صور الأعطال والصيانة')]));
 Widget section(IconData i,String t,String s)=>Container(padding:const EdgeInsets.all(17),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(18)),child:ListTile(contentPadding:EdgeInsets.zero,leading:Icon(i,color:red),title:Text(t,style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text(s,style:const TextStyle(color:muted))));
}


class MapPicker extends StatefulWidget {
  const MapPicker({super.key});
  @override State<MapPicker> createState() => _MapPickerState();
}

class _MapPickerState extends State<MapPicker> {
  LatLng selected = const LatLng(28.3838, 36.5550);

  @override
  void initState() {
    super.initState();
    _getLocation();
  }

  Future<void> _getLocation() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) return;
      var p = await Geolocator.checkPermission();
      if (p == LocationPermission.denied) {
        p = await Geolocator.requestPermission();
      }
      if (p == LocationPermission.denied ||
          p == LocationPermission.deniedForever) return;
      final pos = await Geolocator.getCurrentPosition();
      if (mounted) {
        setState(() => selected = LatLng(pos.latitude, pos.longitude));
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('تحديد موقع العطل',
            style: TextStyle(fontWeight: FontWeight.w800)),
      ),
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition:
                CameraPosition(target: selected, zoom: 14),
            markers: {
              Marker(
                markerId: const MarkerId('fault'),
                position: selected,
              ),
            },
            onTap: (p) => setState(() => selected = p),
            myLocationEnabled: true,
            myLocationButtonEnabled: true,
          ),
          Positioned(
            left: 18,
            right: 18,
            bottom: 22,
            child: FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: red,
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              onPressed: () => Navigator.pop(context, selected),
              icon: const Icon(Icons.check),
              label: const Text('تأكيد الموقع',
                  style: TextStyle(fontWeight: FontWeight.w800)),
            ),
          ),
        ],
      ),
    );
  }
}
