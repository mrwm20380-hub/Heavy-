
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const FleetApp());
}

class FleetApp extends StatelessWidget {
  const FleetApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'صيانة الأسطول',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorSchemeSeed: Colors.blue,
        scaffoldBackgroundColor: const Color(0xfff5f7fa),
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: HomePage(),
      ),
    );
  }
}

class Vehicle {
  String id, plate, type, model, mileage;
  Vehicle({
    required this.id,
    required this.plate,
    required this.type,
    required this.model,
    required this.mileage,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'plate': plate,
        'type': type,
        'model': model,
        'mileage': mileage,
      };

  factory Vehicle.fromJson(Map<String, dynamic> j) => Vehicle(
        id: j['id'] ?? '',
        plate: j['plate'] ?? '',
        type: j['type'] ?? '',
        model: j['model'] ?? '',
        mileage: j['mileage'] ?? '',
      );
}

class Fault {
  String id, vehicle, title, details, severity, date;
  Fault({
    required this.id,
    required this.vehicle,
    required this.title,
    required this.details,
    required this.severity,
    required this.date,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'vehicle': vehicle,
        'title': title,
        'details': details,
        'severity': severity,
        'date': date,
      };

  factory Fault.fromJson(Map<String, dynamic> j) => Fault(
        id: j['id'] ?? '',
        vehicle: j['vehicle'] ?? '',
        title: j['title'] ?? '',
        details: j['details'] ?? '',
        severity: j['severity'] ?? 'متوسطة',
        date: j['date'] ?? '',
      );
}

class Maintenance {
  String id, vehicle, service, mileage, cost, date, status;
  Maintenance({
    required this.id,
    required this.vehicle,
    required this.service,
    required this.mileage,
    required this.cost,
    required this.date,
    required this.status,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'vehicle': vehicle,
        'service': service,
        'mileage': mileage,
        'cost': cost,
        'date': date,
        'status': status,
      };

  factory Maintenance.fromJson(Map<String, dynamic> j) => Maintenance(
        id: j['id'] ?? '',
        vehicle: j['vehicle'] ?? '',
        service: j['service'] ?? '',
        mileage: j['mileage'] ?? '',
        cost: j['cost'] ?? '',
        date: j['date'] ?? '',
        status: j['status'] ?? 'مكتملة',
      );
}

class AppStore extends ChangeNotifier {
  static final AppStore instance = AppStore._();
  AppStore._();

  List<Vehicle> vehicles = [];
  List<Fault> faults = [];
  List<Maintenance> maintenance = [];

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    vehicles = _decode(p.getString('vehicles'), Vehicle.fromJson);
    faults = _decode(p.getString('faults'), Fault.fromJson);
    maintenance = _decode(p.getString('maintenance'), Maintenance.fromJson);
    notifyListeners();
  }

  List<T> _decode<T>(String? raw, T Function(Map<String, dynamic>) factory) {
    if (raw == null) return [];
    final list = jsonDecode(raw) as List;
    return list.map((e) => factory(Map<String, dynamic>.from(e))).toList();
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('vehicles', jsonEncode(vehicles.map((e) => e.toJson()).toList()));
    await p.setString('faults', jsonEncode(faults.map((e) => e.toJson()).toList()));
    await p.setString('maintenance', jsonEncode(maintenance.map((e) => e.toJson()).toList()));
    notifyListeners();
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;

  @override
  void initState() {
    super.initState();
    AppStore.instance.load();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      const DashboardPage(),
      const VehiclesPage(),
      const FaultsPage(),
      const MaintenancePage(),
    ];

    return AnimatedBuilder(
      animation: AppStore.instance,
      builder: (_, __) => Scaffold(
        appBar: AppBar(
          title: const Text('صيانة الأسطول',
              style: TextStyle(fontWeight: FontWeight.bold)),
          centerTitle: true,
        ),
        body: pages[index],
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (i) => setState(() => index = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.local_shipping_outlined), selectedIcon: Icon(Icons.local_shipping), label: 'المركبات'),
            NavigationDestination(icon: Icon(Icons.warning_amber_outlined), selectedIcon: Icon(Icons.warning), label: 'الأعطال'),
            NavigationDestination(icon: Icon(Icons.build_outlined), selectedIcon: Icon(Icons.build), label: 'الصيانة'),
          ],
        ),
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppStore.instance;
    final urgent = s.faults.where((f) => f.severity == 'عالية').length;
    final totalCost = s.maintenance.fold<double>(
      0, (sum, m) => sum + (double.tryParse(m.cost) ?? 0),
    );

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('لوحة التحكم',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(child: StatCard('المركبات', '${s.vehicles.length}', Icons.local_shipping)),
            const SizedBox(width: 10),
            Expanded(child: StatCard('الأعطال', '${s.faults.length}', Icons.warning)),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(child: StatCard('أعطال عاجلة', '$urgent', Icons.priority_high)),
            const SizedBox(width: 10),
            Expanded(child: StatCard('تكلفة الصيانة', '${totalCost.toStringAsFixed(0)} ر.س', Icons.payments)),
          ],
        ),
        const SizedBox(height: 22),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('إجراءات سريعة',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    ActionButton('إضافة مركبة', Icons.add, () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const AddVehiclePage()));
                    }),
                    ActionButton('بلاغ عطل', Icons.report_problem, () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const AddFaultPage()));
                    }),
                    ActionButton('تسجيل صيانة', Icons.build, () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const AddMaintenancePage()));
                    }),
                  ],
                )
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class StatCard extends StatelessWidget {
  final String title, value;
  final IconData icon;
  const StatCard(this.title, this.value, this.icon, {super.key});

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Icon(icon, size: 30),
              const SizedBox(height: 8),
              Text(value, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
              Text(title),
            ],
          ),
        ),
      );
}

class ActionButton extends StatelessWidget {
  final String text;
  final IconData icon;
  final VoidCallback onTap;
  const ActionButton(this.text, this.icon, this.onTap, {super.key});

  @override
  Widget build(BuildContext context) => FilledButton.icon(
        onPressed: onTap,
        icon: Icon(icon),
        label: Text(text),
      );
}

class VehiclesPage extends StatelessWidget {
  const VehiclesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final list = AppStore.instance.vehicles;
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddVehiclePage())),
        icon: const Icon(Icons.add),
        label: const Text('مركبة جديدة'),
      ),
      body: list.isEmpty
          ? const EmptyState('لا توجد مركبات', 'أضف أول شاحنة أو تريلا للأسطول')
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: list.length,
              itemBuilder: (_, i) {
                final v = list[i];
                return Card(
                  child: ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.local_shipping)),
                    title: Text(v.plate, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('${v.type} • ${v.model} • ${v.mileage} كم'),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        list.removeAt(i);
                        await AppStore.instance.save();
                      },
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class FaultsPage extends StatelessWidget {
  const FaultsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final list = AppStore.instance.faults;
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddFaultPage())),
        icon: const Icon(Icons.add),
        label: const Text('بلاغ عطل'),
      ),
      body: list.isEmpty
          ? const EmptyState('لا توجد بلاغات', 'سجل العطل فور ظهوره لتسهيل المتابعة')
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: list.length,
              itemBuilder: (_, i) {
                final f = list[i];
                final high = f.severity == 'عالية';
                return Card(
                  child: ListTile(
                    leading: CircleAvatar(
                      child: Icon(high ? Icons.priority_high : Icons.warning_amber),
                    ),
                    title: Text(f.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('${f.vehicle} • ${f.details}\n${f.date}'),
                    isThreeLine: true,
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        list.removeAt(i);
                        await AppStore.instance.save();
                      },
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class MaintenancePage extends StatelessWidget {
  const MaintenancePage({super.key});

  @override
  Widget build(BuildContext context) {
    final list = AppStore.instance.maintenance;
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddMaintenancePage())),
        icon: const Icon(Icons.add),
        label: const Text('تسجيل صيانة'),
      ),
      body: list.isEmpty
          ? const EmptyState('لا توجد عمليات صيانة', 'سجل تغيير الزيت والإصلاحات وجميع الأعمال')
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: list.length,
              itemBuilder: (_, i) {
                final m = list[i];
                return Card(
                  child: ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.build)),
                    title: Text(m.service, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('${m.vehicle} • ${m.mileage} كم • ${m.date}\nالتكلفة: ${m.cost} ر.س'),
                    isThreeLine: true,
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        list.removeAt(i);
                        await AppStore.instance.save();
                      },
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class EmptyState extends StatelessWidget {
  final String title, subtitle;
  const EmptyState(this.title, this.subtitle, {super.key});

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(30),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.inventory_2_outlined, size: 70),
              const SizedBox(height: 15),
              Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text(subtitle, textAlign: TextAlign.center),
            ],
          ),
        ),
      );
}

class AddVehiclePage extends StatefulWidget {
  const AddVehiclePage({super.key});
  @override
  State<AddVehiclePage> createState() => _AddVehiclePageState();
}

class _AddVehiclePageState extends State<AddVehiclePage> {
  final plate = TextEditingController();
  final type = TextEditingController(text: 'شاحنة');
  final model = TextEditingController();
  final mileage = TextEditingController();

  Future<void> save() async {
    if (plate.text.trim().isEmpty) return;
    AppStore.instance.vehicles.add(Vehicle(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      plate: plate.text.trim(),
      type: type.text.trim(),
      model: model.text.trim(),
      mileage: mileage.text.trim(),
    ));
    await AppStore.instance.save();
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => FormPage(
        title: 'إضافة مركبة',
        children: [
          Field(plate, 'رقم اللوحة', Icons.confirmation_number),
          Field(type, 'نوع المركبة', Icons.local_shipping),
          Field(model, 'الموديل', Icons.calendar_month, keyboard: TextInputType.number),
          Field(mileage, 'العداد بالكيلومتر', Icons.speed, keyboard: TextInputType.number),
          FilledButton.icon(onPressed: save, icon: const Icon(Icons.save), label: const Text('حفظ المركبة')),
        ],
      );
}

class AddFaultPage extends StatefulWidget {
  const AddFaultPage({super.key});
  @override
  State<AddFaultPage> createState() => _AddFaultPageState();
}

class _AddFaultPageState extends State<AddFaultPage> {
  final vehicle = TextEditingController();
  final title = TextEditingController();
  final details = TextEditingController();
  String severity = 'متوسطة';

  Future<void> save() async {
    if (title.text.trim().isEmpty) return;
    AppStore.instance.faults.add(Fault(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      vehicle: vehicle.text.trim(),
      title: title.text.trim(),
      details: details.text.trim(),
      severity: severity,
      date: DateTime.now().toString().split(' ').first,
    ));
    await AppStore.instance.save();
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => FormPage(
        title: 'بلاغ عطل',
        children: [
          Field(vehicle, 'رقم المركبة / اللوحة', Icons.local_shipping),
          Field(title, 'نوع العطل', Icons.warning),
          Field(details, 'وصف المشكلة', Icons.notes, maxLines: 4),
          DropdownButtonFormField<String>(
            value: severity,
            decoration: const InputDecoration(labelText: 'درجة الخطورة', border: OutlineInputBorder()),
            items: const [
              DropdownMenuItem(value: 'منخفضة', child: Text('منخفضة')),
              DropdownMenuItem(value: 'متوسطة', child: Text('متوسطة')),
              DropdownMenuItem(value: 'عالية', child: Text('عالية')),
            ],
            onChanged: (v) => setState(() => severity = v ?? 'متوسطة'),
          ),
          FilledButton.icon(onPressed: save, icon: const Icon(Icons.send), label: const Text('حفظ البلاغ')),
        ],
      );
}

class AddMaintenancePage extends StatefulWidget {
  const AddMaintenancePage({super.key});
  @override
  State<AddMaintenancePage> createState() => _AddMaintenancePageState();
}

class _AddMaintenancePageState extends State<AddMaintenancePage> {
  final vehicle = TextEditingController();
  final service = TextEditingController();
  final mileage = TextEditingController();
  final cost = TextEditingController();

  Future<void> save() async {
    if (service.text.trim().isEmpty) return;
    AppStore.instance.maintenance.add(Maintenance(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      vehicle: vehicle.text.trim(),
      service: service.text.trim(),
      mileage: mileage.text.trim(),
      cost: cost.text.trim(),
      date: DateTime.now().toString().split(' ').first,
      status: 'مكتملة',
    ));
    await AppStore.instance.save();
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => FormPage(
        title: 'تسجيل صيانة',
        children: [
          Field(vehicle, 'رقم المركبة / اللوحة', Icons.local_shipping),
          Field(service, 'نوع الصيانة', Icons.build),
          Field(mileage, 'العداد وقت الصيانة', Icons.speed, keyboard: TextInputType.number),
          Field(cost, 'التكلفة بالريال', Icons.payments, keyboard: TextInputType.number),
          FilledButton.icon(onPressed: save, icon: const Icon(Icons.save), label: const Text('حفظ العملية')),
        ],
      );
}

class FormPage extends StatelessWidget {
  final String title;
  final List<Widget> children;
  const FormPage({required this.title, required this.children, super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(title)),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            ...children.expand((w) => [w, const SizedBox(height: 14)]),
          ],
        ),
      );
}

class Field extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final IconData icon;
  final int maxLines;
  final TextInputType? keyboard;

  const Field(this.controller, this.label, this.icon,
      {this.maxLines = 1, this.keyboard, super.key});

  @override
  Widget build(BuildContext context) => TextField(
        controller: controller,
        maxLines: maxLines,
        keyboardType: keyboard,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
          border: const OutlineInputBorder(),
        ),
      );
}
