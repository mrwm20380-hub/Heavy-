import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

void main() => runApp(const RawasiApp());

class RawasiApp extends StatelessWidget {
  const RawasiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'رواسي الشاهقة',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.red),
        fontFamily: 'sans',
      ),
      home: const RolePage(),
    );
  }
}

class RolePage extends StatelessWidget {
  const RolePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('رواسي الشاهقة')),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 30),
              const Icon(Icons.local_shipping, size: 90),
              const SizedBox(height: 20),
              const Text('إدارة أسطول النقل والصيانة',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 35),
              FilledButton.icon(
                icon: const Icon(Icons.person),
                label: const Text('دخول السائق'),
                onPressed: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const DriverHome())),
              ),
              const SizedBox(height: 14),
              FilledButton.tonalIcon(
                icon: const Icon(Icons.admin_panel_settings),
                label: const Text('دخول المشرف'),
                onPressed: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const SupervisorHome())),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class DriverHome extends StatefulWidget {
  const DriverHome({super.key});
  @override State<DriverHome> createState() => _DriverHomeState();
}

class _DriverHomeState extends State<DriverHome> {
  final List<Map<String, dynamic>> faults = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تطبيق السائق')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.local_shipping),
              title: const Text('المركبة المخصصة'),
              subtitle: const Text('شاحنة تجريبية • لوحة 1234'),
              trailing: const Text('جاهزة'),
            ),
          ),
          const SizedBox(height: 12),
          Text('بلاغاتي', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          if (faults.isEmpty)
            const Card(child: Padding(
              padding: EdgeInsets.all(20),
              child: Text('لا توجد بلاغات حتى الآن'),
            ))
          else
            ...faults.map((f) => Card(
              child: ListTile(
                leading: const Icon(Icons.warning),
                title: Text(f['type']),
                subtitle: Text(f['description']),
                trailing: Text(f['severity']),
              ),
            )),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final result = await Navigator.push<Map<String, dynamic>>(
            context, MaterialPageRoute(builder: (_) => const AddFaultPage()));
          if (result != null) setState(() => faults.insert(0, result));
        },
        icon: const Icon(Icons.camera_alt),
        label: const Text('تصوير عطل'),
      ),
    );
  }
}

class AddFaultPage extends StatefulWidget {
  const AddFaultPage({super.key});
  @override State<AddFaultPage> createState() => _AddFaultPageState();
}

class _AddFaultPageState extends State<AddFaultPage> {
  final desc = TextEditingController();
  final picker = ImagePicker();
  final List<XFile> pics = [];
  String type = 'فرامل';
  String severity = 'عادي';

  Future<void> takePhoto() async {
    final photo = await picker.pickImage(
      source: ImageSource.camera, imageQuality: 80);
    if (photo != null) setState(() => pics.add(photo));
  }

  void submit() {
    if (pics.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يجب تصوير العطل بالكاميرا قبل الإرسال')));
      return;
    }
    if (desc.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اكتب وصف العطل')));
      return;
    }
    Navigator.pop(context, {
      'type': type,
      'severity': severity,
      'description': desc.text.trim(),
      'photos': pics.length,
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('إضافة عطل')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        DropdownButtonFormField<String>(
          value: type,
          decoration: const InputDecoration(labelText: 'نوع العطل'),
          items: ['فرامل','إطارات','محرك','كهرباء','تعليق','تسريب','إضاءة','أخرى']
              .map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
          onChanged: (v) => setState(() => type = v!),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: severity,
          decoration: const InputDecoration(labelText: 'درجة الخطورة'),
          items: ['عادي','متوسط','خطير','إيقاف فوري']
              .map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
          onChanged: (v) => setState(() => severity = v!),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: desc, maxLines: 4,
          decoration: const InputDecoration(
            labelText: 'وصف العطل', border: OutlineInputBorder()),
        ),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: takePhoto,
          icon: const Icon(Icons.camera_alt),
          label: const Text('تصوير العطل (إجباري)'),
        ),
        const SizedBox(height: 10),
        if (pics.isNotEmpty)
          Card(child: Padding(
            padding: const EdgeInsets.all(12),
            child: Text('تم تصوير ${pics.length} صورة ✓'),
          )),
        if (pics.isNotEmpty)
          SizedBox(
            height: 120,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: pics.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) => Image.file(File(pics[i].path),
                  width: 120, fit: BoxFit.cover),
            ),
          ),
        const SizedBox(height: 20),
        FilledButton(
          onPressed: submit,
          child: const Padding(
            padding: EdgeInsets.all(14),
            child: Text('إرسال البلاغ'),
          ),
        ),
      ],
    ),
  );
}

class SupervisorHome extends StatefulWidget {
  const SupervisorHome({super.key});
  @override State<SupervisorHome> createState() => _SupervisorHomeState();
}

class _SupervisorHomeState extends State<SupervisorHome> {
  int tab = 0;
  final vehicles = [
    {'plate':'1234 أ ب','name':'شاحنة 1','status':'تعمل'},
    {'plate':'5678 ج د','name':'شاحنة 2','status':'تعمل'},
    {'plate':'9012 هـ و','name':'شاحنة 3','status':'صيانة'},
  ];

  @override
  Widget build(BuildContext context) {
    final pages = [
      _dashboard(),
      _vehicles(),
      const Center(child: Text('سجل الصيانة — سيتم تطويره في النسخة التالية')),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة المشرف')),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.local_shipping), label: 'المركبات'),
          NavigationDestination(icon: Icon(Icons.build), label: 'الصيانة'),
        ],
      ),
    );
  }

  Widget _dashboard() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('لوحة التحكم',
        style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
      const SizedBox(height: 16),
      Row(children: [
        Expanded(child: _stat('المركبات', '3', Icons.local_shipping)),
        const SizedBox(width: 10),
        Expanded(child: _stat('أعطال مفتوحة', '0', Icons.warning)),
      ]),
      const SizedBox(height: 10),
      _stat('أعطال عاجلة', '0', Icons.priority_high),
      const SizedBox(height: 20),
      const Card(child: ListTile(
        leading: Icon(Icons.sync),
        title: Text('التحديث الفوري'),
        subtitle: Text('سيتم تفعيله عند ربط Firebase'),
      )),
    ],
  );

  Widget _stat(String title, String value, IconData icon) => Card(
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Row(children: [
        Icon(icon, size: 34),
        const SizedBox(width: 14),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title), Text(value,
            style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
        ]),
      ]),
    ),
  );

  Widget _vehicles() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('المركبات',
        style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      ...vehicles.map((v) => Card(
        child: ListTile(
          leading: const Icon(Icons.local_shipping),
          title: Text(v['name']!),
          subtitle: Text('لوحة: ${v['plate']}'),
          trailing: Text(v['status']!),
          onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => VehicleDetails(vehicle: v))),
        ),
      )),
    ],
  );
}

class VehicleDetails extends StatelessWidget {
  final Map<String,String> vehicle;
  const VehicleDetails({super.key, required this.vehicle});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(vehicle['name']!)),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(child: ListTile(
          leading: const Icon(Icons.confirmation_number),
          title: const Text('رقم اللوحة'),
          subtitle: Text(vehicle['plate']!),
        )),
        Card(child: const ListTile(
          leading: Icon(Icons.warning),
          title: Text('الأعطال السابقة'),
          subtitle: Text('لا توجد بيانات تجريبية'),
        )),
        Card(child: const ListTile(
          leading: Icon(Icons.build),
          title: Text('سجل الصيانة'),
          subtitle: Text('لا توجد بيانات تجريبية'),
        )),
      ],
    ),
  );
}
