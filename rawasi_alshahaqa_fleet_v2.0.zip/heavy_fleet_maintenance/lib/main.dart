
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

const navy = Color(0xff0D1B2A);
const red = Color(0xffE30613);
const black = Color(0xff111111);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Store.instance.load();
  runApp(const RawasiApp());
}

class RawasiApp extends StatelessWidget {
  const RawasiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'رواسي الشاهقة',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: navy),
        scaffoldBackgroundColor: const Color(0xfff5f7fa),
        appBarTheme: const AppBarTheme(
          backgroundColor: navy,
          foregroundColor: Colors.white,
          centerTitle: true,
        ),
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: RolePage(),
      ),
    );
  }
}

class Vehicle {
  final String id, plate, type, model, mileage;
  Vehicle({required this.id, required this.plate, required this.type, required this.model, required this.mileage});
  Map<String,dynamic> toJson()=>{'id':id,'plate':plate,'type':type,'model':model,'mileage':mileage};
  factory Vehicle.fromJson(Map<String,dynamic> j)=>Vehicle(
    id:j['id']??'',plate:j['plate']??'',type:j['type']??'',model:j['model']??'',mileage:j['mileage']??'');
}

class Fault {
  final String id, vehicleId, title, details, severity, date, status, driver;
  final List<String> images;
  Fault({required this.id,required this.vehicleId,required this.title,required this.details,required this.severity,
    required this.date,required this.status,required this.driver,required this.images});
  Map<String,dynamic> toJson()=>{'id':id,'vehicleId':vehicleId,'title':title,'details':details,'severity':severity,
    'date':date,'status':status,'driver':driver,'images':images};
  factory Fault.fromJson(Map<String,dynamic> j)=>Fault(id:j['id']??'',vehicleId:j['vehicleId']??'',title:j['title']??'',
    details:j['details']??'',severity:j['severity']??'متوسطة',date:j['date']??'',status:j['status']??'جديد',
    driver:j['driver']??'',images:List<String>.from(j['images']??[]));
}

class Maintenance {
  final String id, vehicleId, service, mileage, cost, date, status;
  final List<String> images;
  Maintenance({required this.id,required this.vehicleId,required this.service,required this.mileage,
    required this.cost,required this.date,required this.status,required this.images});
  Map<String,dynamic> toJson()=>{'id':id,'vehicleId':vehicleId,'service':service,'mileage':mileage,'cost':cost,
    'date':date,'status':status,'images':images};
  factory Maintenance.fromJson(Map<String,dynamic> j)=>Maintenance(id:j['id']??'',vehicleId:j['vehicleId']??'',
    service:j['service']??'',mileage:j['mileage']??'',cost:j['cost']??'',date:j['date']??'',
    status:j['status']??'مكتملة',images:List<String>.from(j['images']??[]));
}

class Store extends ChangeNotifier {
  static final instance=Store._();
  Store._();
  final _uuid=const Uuid();
  List<Vehicle> vehicles=[];
  List<Fault> faults=[];
  List<Maintenance> maintenance=[];
  DateTime lastUpdate=DateTime.now();

  Future<void> load() async {
    final p=await SharedPreferences.getInstance();
    vehicles=_decode(p.getString('vehicles'),Vehicle.fromJson);
    faults=_decode(p.getString('faults'),Fault.fromJson);
    maintenance=_decode(p.getString('maintenance'),Maintenance.fromJson);
    lastUpdate=DateTime.now();
  }
  List<T> _decode<T>(String? raw,T Function(Map<String,dynamic>) f){
    if(raw==null||raw.isEmpty)return [];
    try { final l=jsonDecode(raw) as List; return l.map((e)=>f(Map<String,dynamic>.from(e))).toList(); }
    catch(_){return [];}
  }
  Future<void> save(){
    return _saveAndNotify();
  }
  Future<void> _saveAndNotify() async {
    final p=await SharedPreferences.getInstance();
    await p.setString('vehicles',jsonEncode(vehicles.map((e)=>e.toJson()).toList()));
    await p.setString('faults',jsonEncode(faults.map((e)=>e.toJson()).toList()));
    await p.setString('maintenance',jsonEncode(maintenance.map((e)=>e.toJson()).toList()));
    lastUpdate=DateTime.now();
    notifyListeners();
  }
  String newId()=>_uuid.v4();
  Vehicle? vehicle(String id){for(final v in vehicles){if(v.id==id)return v;}return null;}
  Future<void> addVehicle(Vehicle v) async {vehicles.add(v);await _saveAndNotify();}
  Future<void> addFault(Fault f) async {faults.insert(0,f);await _saveAndNotify();}
  Future<void> addMaintenance(Maintenance m) async {maintenance.insert(0,m);await _saveAndNotify();}
  Future<void> updateFaultStatus(String id,String status) async {
    final i=faults.indexWhere((f)=>f.id==id); if(i<0)return;
    final f=faults[i];
    faults[i]=Fault(id:f.id,vehicleId:f.vehicleId,title:f.title,details:f.details,severity:f.severity,date:f.date,
      status:status,driver:f.driver,images:f.images);
    await _saveAndNotify();
  }
}

class RolePage extends StatelessWidget {
  const RolePage({super.key});
  @override Widget build(BuildContext context)=>Scaffold(
    body: Center(child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisSize:MainAxisSize.min,children:[
        _Logo(large:true), const SizedBox(height:24),
        const Text('رواسي الشاهقة',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900,color:navy)),
        const Text('للخدمات اللوجستية',style:TextStyle(fontSize:18,color:red,fontWeight:FontWeight.bold)),
        const SizedBox(height:36),
        _RoleButton(title:'دخول السائق',icon:Icons.person, onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const DriverHome()))),
        const SizedBox(height:12),
        _RoleButton(title:'دخول المشرف',icon:Icons.manage_accounts,onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const SupervisorHome()))),
      ]),
    )),
  );
}

class _Logo extends StatelessWidget {
  final bool large; const _Logo({this.large=false});
  @override Widget build(BuildContext context)=>Container(
    width:large?120:64,height:large?120:64,
    decoration:BoxDecoration(color:navy,borderRadius:BorderRadius.circular(28)),
    child:Center(child:RichText(text:TextSpan(children:[
      TextSpan(text:'A',style:TextStyle(fontSize:large?70:38,fontWeight:FontWeight.w900,color:Colors.white)),
      TextSpan(text:'R',style:TextStyle(fontSize:large?58:32,fontWeight:FontWeight.w900,color:red)),
    ]))),
  );
}

class _RoleButton extends StatelessWidget {
  final String title; final IconData icon; final VoidCallback onTap;
  const _RoleButton({required this.title,required this.icon,required this.onTap});
  @override Widget build(BuildContext context)=>SizedBox(width:double.infinity,height:54,child:ElevatedButton.icon(
    style:ElevatedButton.styleFrom(backgroundColor:navy,foregroundColor:Colors.white),
    onPressed:onTap,icon:Icon(icon),label:Text(title,style:const TextStyle(fontWeight:FontWeight.bold))));
}

class SupervisorHome extends StatefulWidget {
  const SupervisorHome({super.key});
  @override State<SupervisorHome> createState()=>_SupervisorHomeState();
}
class _SupervisorHomeState extends State<SupervisorHome> {
  @override void initState(){super.initState();Store.instance.addListener(_refresh); }
  @override void dispose(){Store.instance.removeListener(_refresh);super.dispose();}
  void _refresh(){if(mounted)setState((){});}
  @override Widget build(BuildContext context){
    final s=Store.instance;
    return Scaffold(
      appBar:AppBar(title:const Text('لوحة المشرف')),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Row(children:[
          Expanded(child:_Stat('المركبات','${s.vehicles.length}',Icons.local_shipping)),
          const SizedBox(width:10),Expanded(child:_Stat('بلاغات جديدة','${s.faults.where((f)=>f.status=="جديد").length}',Icons.warning)),
        ]),
        const SizedBox(height:10),
        Row(children:[
          Expanded(child:_Stat('قيد الصيانة','${s.faults.where((f)=>f.status=="قيد الصيانة").length}',Icons.build)),
          const SizedBox(width:10),Expanded(child:_Stat('إجمالي الصيانة','${s.maintenance.length}',Icons.history)),
        ]),
        const SizedBox(height:18),
        ListTile(title:const Text('آخر تحديث'),subtitle:Text('${s.lastUpdate.hour.toString().padLeft(2,'0')}:${s.lastUpdate.minute.toString().padLeft(2,'0')}')),
        const Divider(),
        const Text('الأعطال الأخيرة',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
        const SizedBox(height:8),
        if(s.faults.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(20),child:Text('لا توجد بلاغات أعطال'))),
        ...s.faults.take(20).map((f)=>_FaultCard(fault:f)),
        const SizedBox(height:18),
        const Text('المركبات',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
        const SizedBox(height:8),
        ...s.vehicles.map((v)=>Card(child:ListTile(
          leading:const Icon(Icons.local_shipping,color:navy),title:Text(v.plate),
          subtitle:Text('${v.type} • ${v.model} • ${v.mileage} كم'),
          trailing:const Icon(Icons.chevron_left),
          onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>VehicleDetails(vehicle:v))),
        ))),
      ]),
      floatingActionButton:FloatingActionButton.extended(
        backgroundColor:red,foregroundColor:Colors.white,onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AddVehiclePage())),
        icon:const Icon(Icons.add),label:const Text('مركبة')),
    );
  }
}

class _Stat extends StatelessWidget {
  final String title,value; final IconData icon; const _Stat(this.title,this.value,this.icon);
  @override Widget build(BuildContext context)=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(children:[
    Icon(icon,color:red,size:30),const SizedBox(height:5),Text(value,style:const TextStyle(fontSize:24,fontWeight:FontWeight.w900)),
    Text(title),
  ])));
}

class _FaultCard extends StatelessWidget {
  final Fault fault; const _FaultCard({required this.fault});
  @override Widget build(BuildContext context){
    final v=Store.instance.vehicle(fault.vehicleId);
    return Card(child:ListTile(
      leading:CircleAvatar(backgroundColor:fault.severity=='عالية'?red:navy,child:const Icon(Icons.warning,color:Colors.white)),
      title:Text(fault.title,style:const TextStyle(fontWeight:FontWeight.bold)),
      subtitle:Text('${v?.plate??"مركبة غير معروفة"} • ${fault.status} • ${fault.date}'),
      trailing:const Icon(Icons.chevron_left),
      onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>FaultDetails(fault:fault))),
    ));
  }
}

class DriverHome extends StatelessWidget {
  const DriverHome({super.key});
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('تطبيق السائق')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(color:navy,child:const Padding(padding:EdgeInsets.all(18),child:Row(children:[
        Icon(Icons.local_shipping,color:Colors.white,size:38),SizedBox(width:12),
        Expanded(child:Text('بلاغات الأعطال والصيانة',style:TextStyle(color:Colors.white,fontSize:20,fontWeight:FontWeight.bold))),
      ]))),
      const SizedBox(height:12),
      if(Store.instance.vehicles.isEmpty)
        const Card(child:Padding(padding:EdgeInsets.all(18),child:Text('لا توجد مركبات مضافة. أضف المركبة من حساب المشرف أولاً.'))),
      ...Store.instance.vehicles.map((v)=>Card(child:ListTile(
        title:Text(v.plate),subtitle:Text('${v.type} • ${v.model}'),
        leading:const Icon(Icons.local_shipping,color:navy),
        trailing:ElevatedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>AddFaultPage(vehicle:v))),
          icon:const Icon(Icons.camera_alt),label:const Text('إبلاغ عن عطل')),
      ))),
      const SizedBox(height:16),
      const Text('بلاغاتي',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      ...Store.instance.faults.map((f)=>_FaultCard(fault:f)),
    ]),
  );
}

class AddVehiclePage extends StatefulWidget { const AddVehiclePage({super.key}); @override State<AddVehiclePage> createState()=>_AddVehiclePageState(); }
class _AddVehiclePageState extends State<AddVehiclePage>{
  final plate=TextEditingController(),type=TextEditingController(),model=TextEditingController(),mileage=TextEditingController();
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('إضافة مركبة')),body:ListView(padding:const EdgeInsets.all(16),children:[
    _field(plate,'رقم اللوحة'),_field(type,'نوع المركبة'),_field(model,'الموديل'),_field(mileage,'العداد بالكيلومتر',TextInputType.number),
    const SizedBox(height:12),ElevatedButton(onPressed:()async{
      if(plate.text.trim().isEmpty)return;
      await Store.instance.addVehicle(Vehicle(id:Store.instance.newId(),plate:plate.text.trim(),type:type.text.trim(),model:model.text.trim(),mileage:mileage.text.trim()));
      if(mounted)Navigator.pop(context);
    },child:const Text('حفظ المركبة')),
  ]));
}

class AddFaultPage extends StatefulWidget {
  final Vehicle? vehicle; const AddFaultPage({super.key,this.vehicle});
  @override State<AddFaultPage> createState()=>_AddFaultPageState();
}
class _AddFaultPageState extends State<AddFaultPage>{
  final title=TextEditingController(),details=TextEditingController();
  String severity='متوسطة'; Vehicle? vehicle; final List<XFile> photos=[];
  final picker=ImagePicker();
  @override void initState(){super.initState();vehicle=widget.vehicle;}
  Future<void> takePhoto()async{final p=await picker.pickImage(source:ImageSource.camera,imageQuality:75);if(p!=null)setState(()=>photos.add(p));}
  Future<void> choosePhoto()async{final list=await picker.pickMultiImage(imageQuality:75);setState(()=>photos.addAll(list));}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('بلاغ عطل')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      DropdownButtonFormField<Vehicle>(value:vehicle,items:Store.instance.vehicles.map((v)=>DropdownMenuItem(value:v,child:Text(v.plate))).toList(),
        onChanged:(v)=>setState(()=>vehicle=v),decoration:const InputDecoration(labelText:'المركبة',border:OutlineInputBorder())),
      const SizedBox(height:12),_field(title,'وصف مختصر'),_field(details,'تفاصيل العطل',TextInputType.multiline,4),
      DropdownButtonFormField<String>(value:severity,items:['منخفضة','متوسطة','عالية'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),
        onChanged:(x)=>setState(()=>severity=x!),decoration:const InputDecoration(labelText:'درجة الخطورة',border:OutlineInputBorder())),
      const SizedBox(height:14),
      Row(children:[
        Expanded(child:OutlinedButton.icon(onPressed:takePhoto,icon:const Icon(Icons.camera_alt),label:const Text('تصوير'))),
        const SizedBox(width:8),Expanded(child:OutlinedButton.icon(onPressed:choosePhoto,icon:const Icon(Icons.photo_library),label:const Text('من المعرض'))),
      ]),
      if(photos.isNotEmpty)SizedBox(height:110,child:ListView.separated(scrollDirection:Axis.horizontal,itemCount:photos.length,itemBuilder:(_,i)=>Image.file(File(photos[i].path),width:110,height:110,fit:BoxFit.cover),separatorBuilder:(_,__)=>const SizedBox(width:8))),
      const SizedBox(height:16),
      ElevatedButton.icon(onPressed:()async{
        if(vehicle==null||title.text.trim().isEmpty)return;
        final encoded=<String>[];
        for(final p in photos){
          final bytes=await File(p.path).readAsBytes();
          encoded.add(base64Encode(bytes));
        }
        await Store.instance.addFault(Fault(id:Store.instance.newId(),vehicleId:vehicle!.id,title:title.text.trim(),details:details.text.trim(),
          severity:severity,date:DateTime.now().toString().substring(0,10),status:'جديد',driver:'السائق',images:encoded));
        if(mounted)Navigator.pop(context);
      },icon:const Icon(Icons.send),label:const Text('إرسال البلاغ')),
    ]));
}

class FaultDetails extends StatelessWidget {
  final Fault fault; const FaultDetails({super.key,required this.fault});
  @override Widget build(BuildContext context){
    final v=Store.instance.vehicle(fault.vehicleId);
    return Scaffold(appBar:AppBar(title:const Text('تفاصيل البلاغ')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Text(fault.title,style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),Text('${v?.plate??''} • ${fault.date}'),
      const SizedBox(height:10),Text(fault.details),const SizedBox(height:12),
      Wrap(spacing:8,children:['جديد','قيد المراجعة','قيد الصيانة','تم الإصلاح'].map((status)=>ChoiceChip(label:Text(status),selected:fault.status==status,
        onSelected:(_)async=>await Store.instance.updateFaultStatus(fault.id,status))).toList()),
      const SizedBox(height:16),
      if(fault.images.isNotEmpty) ...[
        const Text('صور العطل',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
        const SizedBox(height:8),
        ...fault.images.map((b)=>Padding(padding:const EdgeInsets.only(bottom:8),child:Image.memory(base64Decode(b),height:220,fit:BoxFit.cover))),
      ],
      const SizedBox(height:18),
      const Text('سجل الصيانة',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
      ...Store.instance.maintenance.where((m)=>m.vehicleId==fault.vehicleId).map((m)=>_MaintenanceTile(m)),
      const SizedBox(height:10),
      ElevatedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>AddMaintenancePage(vehicle:v))),icon:const Icon(Icons.build),label:const Text('إضافة صيانة')),
    ]);
  }
}

class VehicleDetails extends StatelessWidget {
  final Vehicle vehicle; const VehicleDetails({super.key,required this.vehicle});
  @override Widget build(BuildContext context){
    final faults=Store.instance.faults.where((f)=>f.vehicleId==vehicle.id).toList();
    final maint=Store.instance.maintenance.where((m)=>m.vehicleId==vehicle.id).toList();
    return Scaffold(appBar:AppBar(title:Text('مركبة ${vehicle.plate}')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:ListTile(title:Text(vehicle.plate,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
        subtitle:Text('${vehicle.type} • ${vehicle.model} • ${vehicle.mileage} كم'))),
      const SizedBox(height:12),Text('الأعطال السابقة (${faults.length})',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      ...faults.map((f)=>_FaultCard(fault:f)),
      const SizedBox(height:12),Text('الصيانات السابقة (${maint.length})',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      ...maint.map((m)=>_MaintenanceTile(m)),
      const SizedBox(height:12),ElevatedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>AddMaintenancePage(vehicle:vehicle))),icon:const Icon(Icons.add),label:const Text('تسجيل صيانة')),
    ]);
  }
}

class AddMaintenancePage extends StatefulWidget { final Vehicle? vehicle; const AddMaintenancePage({super.key,this.vehicle}); @override State<AddMaintenancePage> createState()=>_AddMaintenancePageState(); }
class _AddMaintenancePageState extends State<AddMaintenancePage>{
  final service=TextEditingController(),mileage=TextEditingController(),cost=TextEditingController(); Vehicle? vehicle;
  final photos=<XFile>[]; final picker=ImagePicker();
  @override void initState(){super.initState();vehicle=widget.vehicle;}
  Future<void> photosPick()async{final x=await picker.pickMultiImage(imageQuality:75);setState(()=>photos.addAll(x));}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('تسجيل صيانة')),body:ListView(padding:const EdgeInsets.all(16),children:[
    DropdownButtonFormField<Vehicle>(value:vehicle,items:Store.instance.vehicles.map((v)=>DropdownMenuItem(value:v,child:Text(v.plate))).toList(),onChanged:(v)=>setState(()=>vehicle=v),
      decoration:const InputDecoration(labelText:'المركبة',border:OutlineInputBorder())),
    const SizedBox(height:12),_field(service,'نوع الصيانة'),_field(mileage,'العداد',TextInputType.number),_field(cost,'التكلفة بالريال',TextInputType.number),
    OutlinedButton.icon(onPressed:photosPick,icon:const Icon(Icons.photo_library),label:const Text('إضافة صور الصيانة')),
    const SizedBox(height:12),ElevatedButton.icon(onPressed:()async{
      if(vehicle==null||service.text.trim().isEmpty)return;
      final encoded=<String>[];for(final p in photos){encoded.add(base64Encode(await File(p.path).readAsBytes()));}
      await Store.instance.addMaintenance(Maintenance(id:Store.instance.newId(),vehicleId:vehicle!.id,service:service.text.trim(),mileage:mileage.text.trim(),
        cost:cost.text.trim(),date:DateTime.now().toString().substring(0,10),status:'مكتملة',images:encoded));
      if(mounted)Navigator.pop(context);
    },icon:const Icon(Icons.save),label:const Text('حفظ الصيانة')),
  ]));
}

class _MaintenanceTile extends StatelessWidget {
  final Maintenance m; const _MaintenanceTile(this.m);
  @override Widget build(BuildContext context)=>Card(child:ListTile(
    leading:const Icon(Icons.build,color:navy),title:Text(m.service),subtitle:Text('${m.date} • ${m.mileage} كم • ${m.cost} ر.س'),
    trailing:m.images.isEmpty?null:const Icon(Icons.photo_library),
    onTap:()=>showDialog(context:context,builder:(_)=>AlertDialog(title:Text(m.service),content:SizedBox(width:300,child:ListView(
      shrinkWrap:true,children:m.images.map((b)=>Padding(padding:const EdgeInsets.only(bottom:8),child:Image.memory(base64Decode(b)))).toList())),)),
  ));
}

Widget _field(TextEditingController c,String label,[TextInputType type=TextInputType.text,int maxLines=1])=>Padding(
  padding:const EdgeInsets.only(bottom:12),child:TextField(controller:c,keyboardType:type,maxLines:maxLines,decoration:InputDecoration(labelText:label,border:const OutlineInputBorder())));

